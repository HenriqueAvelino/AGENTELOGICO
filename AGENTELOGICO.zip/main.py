import random

def gerar_condicoes_meteorologicas():
    ceu_nublado = random.choice([True, False])
    vento_forte = random.choice([True, False])
    temperatura = random.randint(0, 40)
    return ceu_nublado, vento_forte, temperatura

def decidir_se_deve_chover(ceu_nublado, vento_forte, temperatura):
  if ceu_nublado and temperatura > 20 and not vento_forte:
        return True  # Deve chover
  else:
        return False  # Não deve chover

# Simulando as condições meteorológicas
ceu_nublado, vento_forte, temperatura = gerar_condicoes_meteorologicas()

# Decisão do agente lógico
deve_chover = decidir_se_deve_chover(ceu_nublado, vento_forte, temperatura)

# Exibindo a decisão
if deve_chover:
    print("O agente lógico decidiu que deve chover.")
else:
    print("O agente lógico decidiu que não deve chover.")
